from dao.company_dao import CompanyDao

class CompanyService:
    def __init__(self):
        self.dao=CompanyDao()

    def get_all_companies(self):
        records=self.dao.get_all_companies()

        return records


    def get_company_by_id(self,company_id):

        records=self.dao.get_company_by_id(company_id)

        return records

    def add_company(self,company):
        self.dao.add_company(company)

    def update_company(self,company):
        self.dao.update_company(company)

    def delete_company(self,company_id):
        self.dao.delete_company(company_id)



