from dao.job_dao import JobDao

class JobService:
    def __init__(self):
        self.dao=JobDao()

    def get_all_jobs(self):
        records=self.dao.get_all_jobs()

        return records

    def get_job_by_id(self,job_id):
        records=self.dao.get_job_by_id(job_id)

        return records

    def add_job(self,job):
        self.dao.add_job(job)

    def update_job(self,job):
        self.dao.update_job(job)

    def delete_job(self,job_id):
        self.dao.delete_job(job_id)


    