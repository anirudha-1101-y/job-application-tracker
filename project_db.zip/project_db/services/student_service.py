from dao.student_dao import StudentDao

class StudentService:
    def __init__(self):
        self.dao=StudentDao()

    def get_all_students(self):
        records=self.dao.get_all_students()

        return records

    def get_student_by_id(self,student_id):

        records=self.dao.get_student_by_id(student_id)

        return records

    def add_student(self,student):
        self.dao.add_student(student)


    def update_student(self,student):
        self.dao.update_student(student)

    def delete_student(self,student_id):
        self.dao.delete_student(student_id)



