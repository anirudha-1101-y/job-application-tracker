from dao.application_dao import ApplicationDao

class ApplicationService:
    def __init__(self):
        self.dao=ApplicationDao()

    def get_all_applications(self):
        records=self.dao.get_all_applications()

        return records

    def get_application_by_id(self,application_id):
        records=self.dao.get_application_by_id(application_id)

        return records

    def add_application(self,application):
        self.dao.add_application(application)

    def update_application(self,application):
        self.dao.update_application(application)

    def delete_application(self,application_id):
        self.dao.delete_application(application_id)

    
