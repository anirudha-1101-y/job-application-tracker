from database.connection import Database

class ApplicationDao:
    def __init__(self):
        self.db=Database()

    def get_all_applications(self):
        connection=self.db.connect()
        cursor=connection.cursor()

        try:

            query="select * from application"

            cursor.execute(query)

            records=cursor.fetchall()

            return records

        except Exception as e:
            print("Error :",e)

        finally:

             cursor.close()
             connection.close()

        

    def get_application_by_id(self,application_id):
        connection=self.db.connect()
        cursor=connection.cursor()

        try:

            query="select * from application where application_id=%s"

            cursor.execute(query,(application_id,))

            records=cursor.fetchone()

            return records

        except Exception as e:
            print("Error :",e)

        finally:

            cursor.close()
            connection.close()

        
    def add_application(self,application):
        connection=self.db.connect()
        cursor=connection.cursor()

        try:
            query="insert into application(student_id,job_id,application_date,status) values(%s,%s,%s,%s)"

            cursor.execute(query,(application.student_id,application.job_id,application.application_date,application.status))

            connection.commit()

        except Exception as e:
            print("Error :",e)

        finally:

            cursor.close()
            connection.close()

    def update_application(self,application):
        connection=self.db.connect()
        cursor=connection.cursor()

        try:
            query="update application set student_id=%s,job_id=%s,application_date=%s,status=%s where application_id=%s"

            cursor.execute(query,(application.student_id,application.job_id,application.application_date,application.status,application.application_id))

            connection.commit()

        except Exception as e:
            print("Error :",e)

        finally:

            cursor.close()
            connection.close()

    def delete_application(self,application_id):
        connection=self.db.connect()
        cursor=connection.cursor()
        try:

            query="delete from application where application_id=%s"

            cursor.execute(query,(application_id,))
            connection.commit()

        except Exception as e:
            print("Error :",e)
        finally:

            cursor.close()
            connection.close()
