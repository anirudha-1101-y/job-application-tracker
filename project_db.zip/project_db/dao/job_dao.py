from database.connection import Database

class JobDao:
    def __init__(self):
        self.db=Database()

    def get_all_jobs(self):
        connection=self.db.connect()
        cursor=connection.cursor()

        try:

            query="select * from job"

            cursor.execute(query)
            records=cursor.fetchall()
            return records

        except Exception as e:
            print("Error :",e)

        finally:
            cursor.close()
            connection.close()

    
    def get_job_by_id(self,job_id):
        connection=self.db.connect()
        cursor=connection.cursor()

        try:
            query="select * from job where job_id=%s"

            cursor.execute(query,(job_id,))

            records=cursor.fetchone()
            return records

        except Exception as e:
            print("Error :",e)

        finally:
            cursor.close()
            connection.close()

      

    def add_job(self,job):
        connection=self.db.connect()
        cursor=connection.cursor()

        try:

             query="insert into job(company_id,job_title,salary,required_skill) values (%s,%s,%s,%s)"

             cursor.execute(query,(job.company_id,job.job_title,job.salary,job.required_skill))
             connection.commit()

        except Exception as e:
            print("Error :",e)

        finally:
        
            cursor.close()
            connection.close()

    def update_job(self,job):
        connection=self.db.connect()
        cursor=connection.cursor()

        try:
            query="update job set company_id=%s,job_title=%s,salary=%s,required_skill=%s where job_id=%s"
            cursor.execute(query,(job.company_id,job.job_title,job.salary,job.required_skill,job.job_id))

            connection.commit()

        except Exception as e:
            print("Error:",e)

        finally:
            cursor.close()
            connection.close()

    def delete_job(self,job_id):
        connection=self.db.connect()
        cursor=connection.cursor()

        try:
            query="delete from job where job_id=%s"
            cursor.execute(query,(job_id,))

            connection.commit()

        except Exception as e:
            print("Error :",e)

        finally:
             cursor.close()
             connection.close()


    
