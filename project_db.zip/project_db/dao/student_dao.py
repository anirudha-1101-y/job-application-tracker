from database.connection import Database


class StudentDao:

    def __init__(self):
        self.db = Database()

    def get_all_students(self):
        connection = self.db.connect()
        cursor = connection.cursor()

        try:
            query = "select * from student"
            cursor.execute(query)

            records = cursor.fetchall()
            return records

        except Exception as e:
            print("Error :",e)

        finally:
        

           cursor.close()
           connection.close()

       

    def get_student_by_id(self,student_id):
        connection=self.db.connect()
        cursor=connection.cursor()

        try:
            query="select * from student where student_id=%s"
            cursor.execute(query,(student_id,))
            records=cursor.fetchone()
            return records
        
        except Exception as e:
            print("Error :",e )

        finally:
            
            cursor.close()
            connection.close()
        

    def add_student(self,student):
        connection=self.db.connect()
        cursor=connection.cursor()
        try:
            query="insert into student(name,email,phone,qualification) values(%s,%s,%s,%s)"
            cursor.execute(query,(student.name,student.email,student.phone,student.qualification))
            connection.commit()
            
        except Exception as e:
            print("Error:",e)

        finally:
            
            cursor.close()
            connection.close()

    def update_student(self,student):

        connection=self.db.connect()
        cursor=connection.cursor()

        try:

            query="update student set name=%s,email=%s,phone=%s,qualification=%s where student_id=%s"
            cursor.execute(query,(student.name,student.email,student.phone,student.qualification,student.student_id))
            connection.commit()
        except Exception as e:
            print("Error :",e)

        finally:

            
            cursor.close()
            connection.close()

    def delete_student(self,student_id):

        connection=self.db.connect()
        cursor=connection.cursor()

        try:

            query="delete from student where student_id=%s"
            cursor.execute(query,(student_id,))
            connection.commit()

        except Exception as e:
            print("Error :",e)

        finally:
            
            cursor.close()
            connection.close()





