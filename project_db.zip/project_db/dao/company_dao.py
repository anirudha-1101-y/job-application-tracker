from database.connection import Database
class CompanyDao:
    def __init__(self):
        self.db=Database()

    def get_all_companies(self):
        connection=self.db.connect()
        cursor=connection.cursor()

        try:

            query="select * from company"
            cursor.execute(query)
            records=cursor.fetchall()
            return records

        except Exception as e:

            print("Error :",e)

        finally:

            cursor.close()
            connection.close()

        


    def get_company_by_id(self,company_id):
        connection=self.db.connect()
        cursor=connection.cursor()
        try:

            query="select * from company where company_id=%s "

            cursor.execute(query, (company_id,))

            records=cursor.fetchone()
            return records
        except Exception as e:
            print("Error: ",e)

        finally:
             cursor.close()
             connection.close()

        

    def add_company(self,company):
        connection=self.db.connect()
        cursor=connection.cursor()

        try:

            query="insert into company(company_name,location,industry) values(%s,%s,%s)"

            cursor.execute(query,(company.company_name,company.location,company.industry))

            connection.commit()

        except Exception as e:
            print("Error :",e)

        finally:
            cursor.close()
            connection.close()

    def update_company(self,company):
        connection=self.db.connect()
        cursor=connection.cursor()

        try:

            query="update company set company_name=%s,location=%s,industry=%s where company_id=%s "

            cursor.execute(query,(company.company_name,company.location,company.industry,company.company_id))

            connection.commit()

        except Exception as e:
            print("Error :",e)

        finally:
            cursor.close()
            connection.close()


    def delete_company(self,company_id):
        connection=self.db.connect()
        cursor=connection.cursor()
        try:
            query="delete from company where company_id=%s"

            cursor.execute(query,(company_id,))

            connection.commit()

        except Exception as e:
            print("Error :",e)

        finally:
            cursor.close()
            connection.close()

    
    