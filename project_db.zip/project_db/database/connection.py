import mysql.connector

class Database:
    def connect(self):
        connection = mysql.connector.connect(
            host = "localhost",
            port = 3306,
            user = 'root',
            password = 'password',
            database = 'job'
        )
        return connection
