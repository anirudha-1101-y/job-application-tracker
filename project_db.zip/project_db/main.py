from services.student_service import StudentService
from services.company_service import CompanyService
from services.job_service import JobService
from services.application_service import ApplicationService


from model.student import Student
from model.company import Company
from model.job import Job
from model.application import Application



student_service=StudentService()
company_service=CompanyService()
job_service=JobService()
application_service=ApplicationService()


print("====================================")
print("      JOB APPLICATION TRACKER")
print("====================================")

while True:
    print("\n1. Student Management")
    print("2. Company Management")
    print("3. Job Management")
    print("4. Application Management")
    print("5. Exit")

    ch=int(input("Enter your choices: "))

    match ch:
        case 1:
          while True:
            print("\n--- Student Management ---")
            print("1. Add student")
            print("2. View All Student")
            print("3. Search Student")
            print("4. Update Student")
            print("5. Delete Student")
            print("6. Exit ")

            choice=int(input("enter your choice: "))

            match choice:
                case 1:
                    name=input("Enter Student name :")
                    email=input("Enter email :")
                    phone=input("Enter phone :")
                    qualification=input("Enter qualification :")

                    student=Student(0,name,email,phone,qualification)

                    student_service.add_student(student)

                    print("Student added successfully ...")

                case 2:
                    records=student_service.get_all_students()
                    for student in records:
                        print(student)
                        print()

                case 3:
                    student_id=int(input("Enter student id :"))
                    student=student_service.get_student_by_id(student_id)
                    if student:
                         print(student)
                    else: 
                        print("Student NOT Found.")

                case 4:
                    student_id = int(input("Enter student id :"))
                    name = input("Enter student name :")
                    email = input("Enter email :")
                    phone = input("Enter phone :")
                    qualification = input("Enter qualification :")

                    student = Student(student_id, name, email, phone, qualification)

                    student_service.update_student(student)

                    print("Student updated Successfully ...")
                    
                case 5:
                    student_id=int(input("Enter student id :"))
                    student_service.delete_student(student_id)

                    print("Student Deleted Successfull...")


                case 6:
                    print("Back to Main Menu ")
                    break 
                case _:
                    print("invalid choice")

        case 2:
            while True:
                print("\n ---Company Management ---")
                print("1. Add company")
                print("2. View All Company")
                print("3. Search Company")
                print("4. Update Company")
                print("5. Delete Company")
                print("6. EXIT")

                choice=int(input("enter your choice :"))
                match choice:
                    case 1:
                        company_name=input("Enter company name :")
                        location=input("Enter Location :")
                        industry=input("Enter Industry :")

                        company=Company(0,company_name,location,industry)
                        company_service.add_company(company)

                        print("Company added successfully ...")

                    case 2:
                        records=company_service.get_all_companies()
                        for company in records:
                            print(company)
                            print()

                    case 3:
                        company_id=int(input("Enter Company id :"))
                        company=company_service.get_company_by_id(company_id)

                        if company:
                            print(company)
                        else:
                            print("Company NOT Found")

                    case 4:
                        company_id=int(input("enter company id :"))
                        company_name=input("Enter Company name :")
                        location=input("Enter location :")
                        industry=input("Enter Industry :")

                        company=Company(company_id,company_name,location,industry)
                        company_service.update_company(company)

                        print("Company Updated  Successfully ..")

                    case 5:
                        company_id=int(input("Enter company id :"))
                        company_service.delete_company(company_id)

                        print("Company Deleted Successfully ..")

                    case 6:
                        print("Back to Menu ")
                        break

                    case _:
                        print("Invalid choice")

        case 3:
            while True:
                print("\n ---Job Management ---")
                print("1. Add Job ")
                print("2. View All Jobs")
                print("3. Serch Job ")
                print("4. Updated Job")
                print("5. Delete Job ")
                print("6. Exit ")

                choice=int(input("enter your Choice :"))
                match choice:

                    case 1:
                        company_id=int(input("Enter Company id :"))
                        job_title=input("Enter Job Tile :")
                        salary=float(input("Enter Salary :"))
                        required_skill=input("Enter Required Skills :")

                        job=Job(0,company_id,job_title,salary,required_skill)
                        job_service.add_job(job)

                        print("Job ADDED Successfully ...")

                    case 2:
                        records=job_service.get_all_jobs()
                        for job in records:
                            print(job)
                            print()

                    case 3:
                        job_id=int(input("Enter Job id :"))
                        job=job_service.get_job_by_id(job_id)

                        if job:
                            print(job)

                        else:
                            print("Job NOT Found ")

                    case 4:
                        job_id=int(input("Enter Job id :"))
                        company_id=int(input("Enter Company id :"))
                        job_title=input("Enter Job title :")
                        salary=float(input("Enter Salary :"))
                        required_skill=input("Enter Required skills :")

                        job=Job(job_id,company_id,job_title,salary,required_skill)

                        job_service.update_job(job)

                        print("Job Updated successfully ..")

                    case 5:
                        job_id=int(input("Enter Job id :"))
                        job_service.delete_job(job_id)

                        print("JOB Deleted successfully ")

                    case 6:
                        print("Back To Menu ")
                        break 

                    case _:
                        print("Invalid choice..")

        case 4:
          while True:
            print("\n -- Application Management ---")
            print("1. Add Application")
            print("2. View All Applications ")
            print("3. Search Application")
            print("4. Updated Application")
            print("5. Delete Application ")
            print("6. Exit ")

            choice=int(input("enter your choice :"))

            match choice:
                case 1:
                    student_id=int(input("Enter Student id :"))
                    job_id=int(input("Enter Job id :"))
                    application_date=input("Enter Application Date :")
                    status=input("Enter Status :")

                    app=Application(0,student_id,job_id,application_date,status)
                    application_service.add_application(app)

                    print("Application Added successfully ..")

                case 2:
                    records=application_service.get_all_applications()

                    for app in records:

                        print(app)
                        print()

                case 3:
                    application_id=int(input("Enter Application id :"))
                    records=application_service.get_application_by_id(application_id)

                    if records:
                        print(records)

                    else:
                        print("Application NOT Found")

                case 4:
                    application_id=int(input("Enter Application id :"))
                    student_id=int(input("Enter Student id :"))
                    job_id=int(input("Enter Job id :"))
                    application_date=input("Enter Application date :")
                    status=input("Enter Status :")

                    app=Application(application_id,student_id,job_id,application_date,status)
                    application_service.update_application(app)

                    print("Application Update Successfully ...")

                case 5:
                    application_id=int(input("Enter Applicatio id :"))
                    application_service.delete_application(application_id)

                    print("Application deleted successfully ...")

                case 6:
                    print("Back To Menu ")
                    break 

                case _:
                    print("Invalid choice.")


                

        case 5:
            print("Thankyou For Visiting ....")
            break

        case _:
            print("INVALID CHOICE...")

       