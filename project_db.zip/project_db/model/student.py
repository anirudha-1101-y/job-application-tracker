class Student:
    def __init__(self,student_id,name,email,phone,qualification):
        self.student_id=student_id
        self.name=name
        self.email=email
        self.phone=phone
        self.qualification=qualification
        