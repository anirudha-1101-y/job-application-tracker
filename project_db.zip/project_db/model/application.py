class Application:
    def __init__(self,application_id,student_id,job_id,application_date,status):
        self.application_id=application_id
        self.student_id=student_id
        self.job_id=job_id
        self.application_date=application_date
        self.status=status