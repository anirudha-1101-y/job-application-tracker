class Job:
    def __init__(self,job_id,company_id,job_title,salary,required_skill):
        self.job_id=job_id
        self.company_id=company_id
        self.job_title=job_title
        self.salary=salary
        self.required_skill=required_skill