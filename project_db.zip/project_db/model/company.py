class Company:
    def __init__(self,company_id,company_name,location,industry):
        self.company_id=company_id
        self.company_name=company_name
        self.location=location
        self.industry=industry
        
